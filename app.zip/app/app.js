'use strict';
//1705664719725884
angular.module('myApp', [
  'ui.router'
]).
config(['$locationProvider', '$stateProvider', '$urlRouterProvider', function ($locationProvider, $stateProvider, $urlRouterProvider) {


    $stateProvider.state('root', {
      url: '',
      templateUrl: './view1/view1.html',
      controller: 'dashboardCtrl'
    });

    $stateProvider.state('redirect', {
      url: '/abc',
      templateUrl: './view2/view2.html',
      controller: 'dashboardCtrl',
      resolve: {
        'urlFix': ['$location', function ($location) {
          console.log($location.url());
          $location.url($location.url().replace("#", "?"));
        }]
      }
    });

    $urlRouterProvider.rule(function ($injector, $location) {
      //what this function returns will be set as the $location.url
      var path = $location.path(),
        normalized = path.toLowerCase();
      console.log(normalized);
      if(normalized.indexOf('access_token') > -1) {
        $location.url().replace("#", "?");
      }
      console.info($location.url(),window.location.href);
      if (normalized.indexOf('access_token') > -1) {
        //instead of returning a new url string, I'll just change the $location.path directly so I don't have to worry about constructing a new url string and so a new state change is not triggered
        $location.replace().path('newpath');
      }
      // because we've returned nothing, no state change occurs
    });



  }])
  .controller('dashboardCtrl', ['$scope', function ($scope) {

    $scope.fblogin = function () {
      window.open("https://www.facebook.com/v2.9/dialog/oauth?client_id=1705664719725884&display=popup&response_type=token&redirect_uri=http://localhost:8000/#/abc/", "", "width=400,height=400,top=50%,left=50%");
    };

  }])
  .controller('MainCtrl', ['$scope', function ($scope) {
    $scope.accessToken = '';

  }])
  .controller('redirectURLCtrl', ['$scope', function () {
    console.info(window.location);
  }]);