# importing csv module 
import csv 
import os

# csv file name 
filename = "package.csv"

# initializing the titles and rows list 
fields = [] 
rows = [] 
totalRows = 0
inputString = ""
inputString = raw_input("Enter search query : ") 
print(os.linesep) 


# reading csv file 
with open(filename, 'r') as csvfile: 
	# creating a csv reader object 
	csvreader = csv.reader(csvfile) 
	
	# extracting field names through first row 
	fields = csvreader.next() 

	# extracting each data row one by one 
	for row in csvreader: 
		rows.append(row)
		for i in range(len(row)):
			if i==0 and inputString == row[i]:
				print("---Match Found !!!---",row[i],row[i+1])
			break

	# get total number of rows 
	totalRows = csvreader.line_num

# printing the field names 
print(os.linesep)
print('CSV File Field Names :' + ', '.join(field for field in fields)) 
print(os.linesep)
print('CSV File Total lines :',totalRows)
print(os.linesep)
print('Total rows',rows)
print(os.linesep)



