let id = 1622751126;

let clientId = kheJ4tjurMfyXbtJLMA;

let  clientSecret = yR18xAtcCWJAqaImEUqaIKqb2VGXEYv6wuRmQLAFLM; 

let access-token =11192-RGGmp3ZnkrHO4ZMEJdQxaQ;

https://www.yammer.com/dialog/oauth?client_id=1622751126&redirect_uri=https://onedev1.dev.cba/auth&response_type=token

https://www.yammer.com/oauth2/access_token?client_id=[:client_id]&client_secret=[:client_secret]&code=[:code]&grant_type=authorization_code