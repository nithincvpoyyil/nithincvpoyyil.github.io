var express = require('express'),
    htmlDir = './html/'
var app = express();

var Client = require('node-rest-client').Client;

var client = new Client();

// Set content directories
app.use(express.static(__dirname + '/html'));
app.use('/js', express.static(__dirname + '/js'));
app.use('/css', express.static(__dirname + '/css'));
app.use("/image", express.static(__dirname + '/image'));

app.get('/', function (request, response) {
    response.sendfile(htmlDir + 'turbocalendulator.html');
});

app.get('/auth/:id', (request, response) => {
    response.writeHead(200, {
        "Content-Type": "application/json"
    });

    // direct way 
    // direct way 
    var client = new Client();

    let token = request.params.id;

    console.log(token)

    var args = {
        data: {
        }, // data passed to REST method (only useful in POST, PUT or PATCH methods) 
        path: {
        }, // path substitution var 
        parameters: {
        }, // this is serialized as URL parameters 
        headers: {
            "Authorization": "Bearer "+token
        } // request headers 
    };


    client.get("https://www.yammer.com/api/v1/groups.json?mine=1", args,
        function (data, resp) {
            response.end(JSON.stringify(data,null,2))
        });

});

var port = process.env.PORT || 5000;
app.listen(port, function () {
    console.log("Listening on " + port);
});